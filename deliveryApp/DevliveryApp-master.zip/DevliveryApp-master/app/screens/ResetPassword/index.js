import ResetPasswordContainer from './ResetPasswordContainer';
export default ResetPasswordContainer;

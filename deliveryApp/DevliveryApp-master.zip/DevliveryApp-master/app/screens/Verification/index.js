import VerificationContainer from './VerificationContainer';
export default VerificationContainer;

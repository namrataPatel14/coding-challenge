import EditProfileImageContainer from './EditProfileImageContainer';
export default EditProfileImageContainer;

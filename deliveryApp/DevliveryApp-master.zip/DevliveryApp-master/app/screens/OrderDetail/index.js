import OrderDetailContainer from './OrderDetailContainer';
export default OrderDetailContainer;

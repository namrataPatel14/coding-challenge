import NoInternetContainer from './NoInternetContainer';
export default NoInternetContainer;

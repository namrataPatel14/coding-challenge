import MyOrdersContainer from './MyOrdersContainer';
export default MyOrdersContainer;

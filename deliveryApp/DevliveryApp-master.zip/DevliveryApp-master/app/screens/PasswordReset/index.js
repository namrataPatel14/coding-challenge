import PasswordResetContainer from './PasswordResetContainer';
export default PasswordResetContainer;

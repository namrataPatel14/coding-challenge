import React, { Component } from 'react';
import {FlatList, View } from 'react-native';
import { Text, ListItem, Left, Body, Right } from "native-base";
import globalStyles from '../../assets/css/globalStyles';


class HomeView extends Component {
    constructor() {
        super();
        this.state = {
          
        };
      }

      
     
    render() {
        
        return (
            <View>
              <Text>Hello</Text>
            </View>
          );
    }
} 
export default HomeView;

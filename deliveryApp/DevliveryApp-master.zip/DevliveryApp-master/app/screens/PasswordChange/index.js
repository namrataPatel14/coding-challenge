import PasswordChangeContainer from './PasswordChangeContainer';
export default PasswordChangeContainer;
